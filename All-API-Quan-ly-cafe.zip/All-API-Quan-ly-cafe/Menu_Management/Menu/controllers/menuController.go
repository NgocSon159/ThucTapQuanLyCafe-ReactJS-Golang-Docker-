package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"Project/Menu_Management/Menu/common"
	"Project/Menu_Management/Menu/data"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

// CreateOneMenuEndPoint .
func CreateOneMenuEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource MenuResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Menus data", 500)
		return
	}

	menu := &dataResource.Data
	context := NewContext()
	defer context.Close()

	menucol := context.DbCollection("Menus")
	repo := &data.Repository{MenuCol: menucol}

	err = repo.CreateOneMenu(menu)
	if nil != err {
		common.DisplayAppError(w, errors.New("Invalid"), err.Error(), 500)
		return
	}
	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

// GetAllMenusEndPoint .
func GetAllMenusEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()

	menucol := context.DbCollection("Menus")
	repo := &data.Repository{MenuCol: menucol}

	menus := repo.GetAllMenus()
	j, err := json.Marshal(MenusResource{Data: menus})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// GetMenuByIDEndPoint .
func GetMenuByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	menucol := context.DbCollection("Menus")
	repo := &data.Repository{MenuCol: menucol}

	menu, err := repo.GetMenuByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(menu)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// UpdateMenuEndPoint .
func UpdateMenuEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource MenuResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Employee data", 500)
		return
	}

	menu := &dataResource.Data
	menu.MenuID = id

	context := NewContext()
	defer context.Close()

	menucol := context.DbCollection("Menus")
	repo := &data.Repository{MenuCol: menucol}

	if err := repo.UpdateMenu(menu); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

// DeleteMenuByIDEndPoint .
func DeleteMenuByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	menucol := context.DbCollection("Menus")
	repo := &data.Repository{MenuCol: menucol}

	if err := repo.DeleteOneMenu(id); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

// Search Menus by Name .
func SearchMenuByNameEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	name := vars["name"]

	context := NewContext()
	defer context.Close()

	menucol := context.DbCollection("Menus")
	repo := &data.Repository{MenuCol: menucol}

	listmenu, err := repo.SearchMenuByName(name)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(listmenu)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}
