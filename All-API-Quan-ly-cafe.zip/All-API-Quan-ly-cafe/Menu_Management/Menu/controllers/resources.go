package controllers

import "Project/Menu_Management/Menu/models"

type (
	//MenusResource .
	MenusResource struct {
		Data []models.Menu `json:"data"`
	}

	//MenuResource .
	MenuResource struct {
		Data models.Menu `json:"data"`
	}

	//MenuDetailsResource .
	MenuDetailsResource struct {
		Data []models.MenuDetail `json:"data"`
	}

	//MenuDetailResource .
	MenuDetailResource struct {
		Data models.MenuDetail `json:"data"`
	}
)
