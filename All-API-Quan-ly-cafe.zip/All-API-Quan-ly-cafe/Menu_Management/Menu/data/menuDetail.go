package data

import (
	"Project/Menu_Management/Menu/models"

	"gopkg.in/mgo.v2/bson"
)

//CreateOne .
func (r *Repository) CreateMenuDetail(menuID string, menuDetails []models.MenuDetail) error {
	var err error

	for i := 0; i < len(menuDetails); i++ {
		objid := bson.NewObjectId()
		menuDetails[i].ID = objid
		menuDetails[i].MenuID = menuID

		var food models.FoodDetail
		r.FoodCol.Find(bson.M{"FoodID": menuDetails[i].FoodID}).One(&food)

		menuDetails[i].Name = food.Name
		menuDetails[i].Price = food.Price
		menuDetails[i].Size = food.Size
		menuDetails[i].CategoryID = food.CategoryID

		checkerr := r.MenuDetailCol.Insert(&menuDetails[i])
		if nil != checkerr {
			err = checkerr
			break
		}
	}

	return err
}

//GetAll .
func (r *Repository) GetDetailsOfOneMenu(menuID string) []models.MenuDetail {
	var details []models.MenuDetail

	iter := r.MenuDetailCol.Find(bson.M{"MenuID": menuID}).Sort("CategoryID").Iter()
	result := models.MenuDetail{}
	for iter.Next(&result) {
		details = append(details, result)
	}
	return details
}

//Search by Name .
func (r *Repository) SearchMenuDetailByFoodName(menuID string, name string) ([]models.MenuDetail, error) {
	var details []models.MenuDetail
	err := r.MenuDetailCol.Find(bson.M{"MenuID": menuID, "Name": bson.RegEx{name, ""}}).All(&details)

	return details, err
}

/*
//Search by ID .
func (r *Repository) SearchMenuDetailByID(id string) ([]models.MenuDetail, error) {
	var details []models.MenuDetail
	err := r.MenuDetailCol.Find(bson.M{"MenuID": bson.RegEx{id, ""}}).All(&details)

	return details, err
}

//Update .
func (r *Repository) UpdateMenuDetail(menuDetail *models.MenuDetail) error {
	err := r.MenuDetailCol.Update(bson.M{"MenuID": menuDetail.MenuID, "FoodID": menuDetail.FoodID},
		bson.M{"$set": bson.M{
			"FoodID": menuDetail.FoodID,
		}})
	return err
}*/

//DeleteOne .
func (r *Repository) DeleteOneMenuDetail(MenuID string, FoodID string) error {
	err := r.MenuDetailCol.Remove(bson.M{"MenuID": MenuID, "FoodID": FoodID})

	return err
}
