package data

import (
	"Project/Menu_Management/Menu/models"
	"errors"
	"strconv"

	"gopkg.in/mgo.v2/bson"
)

//CreateOne .
func (r *Repository) CreateOneMenu(menu *models.Menu) error {
	checkExist, _ := r.MenuCol.Find(bson.M{"MenuID": menu.MenuID}).Count()
	idnumber, _ := r.MenuCol.Find(bson.M{}).Count()
	if checkExist == 0 {
		objid := bson.NewObjectId()
		menu.ID = objid
		idnumber++
		result := strconv.Itoa(idnumber)
		menu.MenuID = "Menu" + result

		menu.Status = true
		err := r.MenuCol.Insert(&menu)
		return err
	}

	return errors.New("Menu already existed")
}

//GetAll .
func (r *Repository) GetAllMenus() []models.Menu {
	var menus []models.Menu

	iter := r.MenuCol.Find(bson.M{"Status": true}).Sort("MenuID").Iter()
	result := models.Menu{}
	for iter.Next(&result) {
		menus = append(menus, result)
	}
	return menus
}

//GetByID .
func (r *Repository) GetMenuByID(id string) (models.Menu, error) {
	var menu models.Menu
	err := r.MenuCol.Find(bson.M{"MenuID": id}).One(&menu)
	return menu, err
}

//Search by Name .
func (r *Repository) SearchMenuByName(name string) ([]models.Menu, error) {
	var menus []models.Menu
	err := r.MenuCol.Find(bson.M{"Name": bson.RegEx{name, ""}}).All(&menus)

	return menus, err
}

//Search by ID .
func (r *Repository) SearchMenuByID(id string) ([]models.Menu, error) {
	var menus []models.Menu
	err := r.MenuCol.Find(bson.M{"MenuID": bson.RegEx{id, ""}}).All(&menus)

	return menus, err
}

//Update .
func (r *Repository) UpdateMenu(menu *models.Menu) error {
	err := r.MenuCol.Update(bson.M{"MenuID": menu.MenuID},
		bson.M{"$set": bson.M{
			"Name":     menu.Name,
			"BranchID": menu.BranchID,
			"Status":   menu.Status,
		}})
	return err
}

//DeleteOne .
func (r *Repository) DeleteOneMenu(id string) error {
	err := r.MenuCol.Update(bson.M{"MenuID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	return err
}
