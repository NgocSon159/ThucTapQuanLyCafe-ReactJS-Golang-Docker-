package models

import (
	"time"

	"gopkg.in/mgo.v2/bson"
)

type (
	//Menu Model
	Menu struct {
		ID        bson.ObjectId `bson:"_id,omitempty"`
		MenuID    string        `bson:"MenuID"`
		Name      string        `bson:"Name"`
		CreatedOn time.Time     `bson:"CreatedOn"`
		BranchID  string        `bson:"BranchID"`
		Status    bool          `bson:"Status"`
	}

	//MenuDetail Model
	MenuDetail struct {
		ID         bson.ObjectId `bson:"_id,omitempty"`
		MenuID     string        `bson:"MenuID"`
		FoodID     string        `bson:"FoodID"`
		Name       string        `bson:"Name"`
		Price      int           `bson:"Price"`
		Size       string        `bson:"Size"`
		CategoryID string        `bson:"CategoryID"`
	}

	//FoodDetail Model
	FoodDetail struct {
		FoodID     string `bson:"FoodID"`
		Name       string `bson:"Name"`
		Price      int    `bson:"Price"`
		Size       string `bson:"Size"`
		CategoryID string `bson:"CategoryID"`
	}
)
