package main

import (
	"Project/Menu_Management/Menu/common"
	"Project/Menu_Management/Menu/controllers"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gorilla/mux"
	. "github.com/smartystreets/goconvey/convey"
)

func TestCreateOneMenuEndPoint_Success(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/menus", controllers.CreateOneMenuEndPoint).Methods("POST")

	common.StartUp()

	menuJSON := `{"data":{
        "MenuID": "Menu003",
        "Name": "Test Menu",
        "BranchID": "BR001"
    }}`

	Convey("Given a HTTP POST request for /menus", t, func() {
		req := httptest.NewRequest("POST", "/menus", strings.NewReader(menuJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 201", func() {
				So(resp.Code, ShouldEqual, 201)
			})
		})

		if resp.Code != 201 {
			t.Errorf("HTTP Status expected: 201, got: %d", resp.Code)
		}
	})
}

func TestCreateOneMenuEndPoint_Exist(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/menus", controllers.CreateOneMenuEndPoint).Methods("POST")

	common.StartUp()

	menuJSON := `{"data":{
        "MenuID": "Menu001",
        "Name": "Menu chi nhánh 1",
        "BranchID": "BR001"
    }}`

	Convey("Given a HTTP POST request for /menus", t, func() {
		req := httptest.NewRequest("POST", "/menus", strings.NewReader(menuJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 500", func() {
				So(resp.Code, ShouldEqual, 500)
			})
		})

		if resp.Code != 500 {
			t.Errorf("HTTP Status expected: 500, got: %d", resp.Code)
		}
	})
}

func TestGetAllMenusEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/menus", controllers.GetAllMenusEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /menus", t, func() {
		req := httptest.NewRequest("GET", "/menus", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestGetMenuByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/menus/{id}", controllers.GetMenuByIDEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /menus/{id}", t, func() {
		req := httptest.NewRequest("GET", "/menus/Menu003", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestUpdateMenuEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/menus/{id}", controllers.UpdateMenuEndPoint).Methods("PUT")

	common.StartUp()

	menuJSON := `{"data":{
        "Name": "Test Menu changed",
        "Image": "https://i.ibb.co/B395Q9G/Vietnamese-Coffee.jpg",
		"Status": true
    }}`

	Convey("Given a HTTP PUT request for /menus/{id}", t, func() {
		req := httptest.NewRequest("PUT", "/menus/Menu003", strings.NewReader(menuJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestDeleteMenuByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/menus/{id}", controllers.DeleteMenuByIDEndPoint).Methods("DELETE")

	common.StartUp()

	Convey("Given a HTTP DELETE request for /menus/{id}", t, func() {
		req := httptest.NewRequest("DELETE", "/menus/Menu003", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 204", func() {
				So(resp.Code, ShouldEqual, 204)
			})
		})

		if resp.Code != 204 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}
