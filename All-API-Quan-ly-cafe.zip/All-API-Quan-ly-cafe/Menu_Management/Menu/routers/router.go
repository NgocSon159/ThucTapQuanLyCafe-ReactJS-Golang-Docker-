package routers

import "github.com/gorilla/mux"

//InitRouter .
func InitRouter() *mux.Router {
	router := mux.NewRouter().StrictSlash(false)

	router = SetMenusRouters(router)
	router = SetMenuDetailsRouters(router)

	return router
}
