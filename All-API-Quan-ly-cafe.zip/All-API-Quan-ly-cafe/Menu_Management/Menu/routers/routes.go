package routers

import (
	"Project/Menu_Management/Menu/controllers"

	"github.com/gorilla/mux"
)

// SetMenusRouters .
func SetMenusRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/menus", controllers.GetAllMenusEndPoint).Methods("GET")
	router.HandleFunc("/menus/{id}", controllers.GetMenuByIDEndPoint).Methods("GET")
	router.HandleFunc("/menus", controllers.CreateOneMenuEndPoint).Methods("POST")
	router.HandleFunc("/menus/{id}", controllers.UpdateMenuEndPoint).Methods("PUT")
	router.HandleFunc("/menus/{id}", controllers.DeleteMenuByIDEndPoint).Methods("DELETE")
	router.HandleFunc("/menus/search/{name}", controllers.SearchMenuByNameEndPoint).Methods("GET")

	return router
}

// SetMenuDetailsRouters .
func SetMenuDetailsRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/menu/details/{id}", controllers.GetDetailsOfOneMenuEndPoint).Methods("GET")
	router.HandleFunc("/menu/details/{id}", controllers.CreateMenuDetailEndPoint).Methods("POST")
	router.HandleFunc("/menu/details/{id}", controllers.DeleteOneMenuDetailEndPoint).Methods("DELETE")
	router.HandleFunc("/menu/details/{id}/search/{name}", controllers.SearchMenuDetailByFoodNameEndPoint).Methods("GET")

	return router
}
