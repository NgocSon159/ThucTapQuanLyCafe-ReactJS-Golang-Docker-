package main

import (
	"Project/Menu_Management/Food/common"
	"Project/Menu_Management/Food/controllers"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gorilla/mux"
	. "github.com/smartystreets/goconvey/convey"
)

func TestCreateOneCategoryEndPoint_Success(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/categories", controllers.CreateOneCategoryEndPoint).Methods("POST")

	common.StartUp()

	categoryJSON := `{"data":{
        "CategoryID": "CA007",
        "Name": "Test Category",
        "Image": "https://i.ibb.co/B395Q9G/Vietnamese-Coffee.jpg",
        "CreatedOn": "2019-03-28T13:55:17.171+00:00"
    }}`

	Convey("Given a HTTP POST request for /categories", t, func() {
		req := httptest.NewRequest("POST", "/categories", strings.NewReader(categoryJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 201", func() {
				So(resp.Code, ShouldEqual, 201)
			})
		})

		if resp.Code != 201 {
			t.Errorf("HTTP Status expected: 201, got: %d", resp.Code)
		}
	})
}

func TestCreateOneCategoryEndPoint_Exist(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/categories", controllers.CreateOneCategoryEndPoint).Methods("POST")

	common.StartUp()

	categoryJSON := `{"data":{
        "CategoryID": "CA007",
        "Name": "Test Category",
        "Image": "https://i.ibb.co/B395Q9G/Vietnamese-Coffee.jpg"
    }}`

	Convey("Given a HTTP POST request for /categories", t, func() {
		req := httptest.NewRequest("POST", "/categories", strings.NewReader(categoryJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 500", func() {
				So(resp.Code, ShouldEqual, 500)
			})
		})

		if resp.Code != 500 {
			t.Errorf("HTTP Status expected: 500, got: %d", resp.Code)
		}
	})
}

func TestGetAllCategoriesEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/categories", controllers.GetAllCategoriesEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /categories", t, func() {
		req := httptest.NewRequest("GET", "/categories", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestGetCategoryByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/categories/{id}", controllers.GetCategoryByIDEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /categories/{id}", t, func() {
		req := httptest.NewRequest("GET", "/categories/CA007", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestUpdateCategoryEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/categories/{id}", controllers.UpdateCategoryEndPoint).Methods("PUT")

	common.StartUp()

	categoryJSON := `{"data":{
        "Name": "Test Category changed",
        "Image": "https://i.ibb.co/B395Q9G/Vietnamese-Coffee.jpg",
		"Status": true
    }}`

	Convey("Given a HTTP PUT request for /categories/{id}", t, func() {
		req := httptest.NewRequest("PUT", "/categories/CA007", strings.NewReader(categoryJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestDeleteCategoryByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/categories/{id}", controllers.DeleteCategoryByIDEndPoint).Methods("DELETE")

	common.StartUp()

	Convey("Given a HTTP DELETE request for /categories/{id}", t, func() {
		req := httptest.NewRequest("DELETE", "/categories/CA007", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 204", func() {
				So(resp.Code, ShouldEqual, 204)
			})
		})

		if resp.Code != 204 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}
