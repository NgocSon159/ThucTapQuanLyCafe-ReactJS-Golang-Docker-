package data

import (
	"Project/Menu_Management/Food/models"
	"errors"
	"strconv"

	"gopkg.in/mgo.v2/bson"
)

//CreateOne .
func (r *Repository) CreateOneFood(food *models.Food) error {
	checkExist, _ := r.FoodCol.Find(bson.M{"FoodID": food.FoodID}).Count()
	idnumber, _ := r.FoodCol.Find(bson.M{}).Count()
	if checkExist == 0 {
		objid := bson.NewObjectId()
		food.ID = objid
		idnumber++
		result := strconv.Itoa(idnumber)
		food.FoodID = "FO" + result

		food.Status = true

		checkCategory, _ := r.CategoryCol.Find(bson.M{"CategoryID": food.CategoryID}).Count()
		if checkCategory == 0 {
			return errors.New("Invalid Category")
		}

		err := r.FoodCol.Insert(&food)
		return err
	}

	return errors.New("Food already existed")
}

//GetAll .
func (r *Repository) GetAllFood() []models.Food {
	var listFood []models.Food
	iter := r.FoodCol.Find(bson.M{"Status": true}).Sort("FoodID").Iter()
	result := models.Food{}
	for iter.Next(&result) {
		listFood = append(listFood, result)
	}
	return listFood
}

//GetByID .
func (r *Repository) GetFoodByID(id string) (models.Food, error) {
	var food models.Food
	err := r.FoodCol.Find(bson.M{"FoodID": id}).One(&food)
	return food, err
}

//Search by Name .
func (r *Repository) SearchFoodByName(name string) ([]models.Food, error) {
	var listFood []models.Food
	err := r.FoodCol.Find(bson.M{"Name": bson.RegEx{name, ""}}).All(&listFood)

	return listFood, err
}

//Search by ID .
func (r *Repository) SearchFoodByID(id string) ([]models.Food, error) {
	var listFood []models.Food
	err := r.FoodCol.Find(bson.M{"FoodID": bson.RegEx{id, ""}}).All(&listFood)

	return listFood, err
}

//Update .
func (r *Repository) UpdateFood(food *models.Food) error {
	err := r.FoodCol.Update(bson.M{"FoodID": food.FoodID},
		bson.M{"$set": bson.M{
			"Name":       food.Name,
			"Price":      food.Price,
			"Size":       food.Size,
			"CategoryID": food.CategoryID,
			"Status":     food.Status,
		}})

	// Update all Menu Details of this Food
	r.MenuDetailCol.UpdateAll(bson.M{"FoodID": food.FoodID},
		bson.M{"$set": bson.M{
			"Name":       food.Name,
			"Price":      food.Price,
			"Size":       food.Size,
			"CategoryID": food.CategoryID,
		}})

	return err
}

//DeleteOne .
func (r *Repository) DeleteOneFood(id string) error {
	err := r.FoodCol.Update(bson.M{"FoodID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	// Remove all Menu Details of this Food
	r.MenuDetailCol.RemoveAll(bson.M{"FoodID": id})

	return err
}
