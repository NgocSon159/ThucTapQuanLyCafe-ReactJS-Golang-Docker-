package data

import (
	"Project/Menu_Management/Food/models"
	"errors"
	"strconv"

	"gopkg.in/mgo.v2/bson"
)

//CreateOne .
func (r *Repository) CreateOneCategory(category *models.Category) error {
	checkExist, _ := r.CategoryCol.Find(bson.M{"CategoryID": category.CategoryID}).Count()
	idnumber, _ := r.CategoryCol.Find(bson.M{}).Count()
	if checkExist == 0 {
		objid := bson.NewObjectId()
		category.ID = objid

		idnumber++
		result := strconv.Itoa(idnumber)
		category.CategoryID = "CA" + result

		category.Status = true
		err := r.CategoryCol.Insert(&category)
		return err
	}

	return errors.New("Category already existed")
}

//GetAll .
func (r *Repository) GetAllCategories() []models.Category {
	var categories []models.Category

	iter := r.CategoryCol.Find(bson.M{"Status": true}).Sort("CategoryID").Iter()
	result := models.Category{}
	for iter.Next(&result) {
		categories = append(categories, result)
	}
	return categories
}

//GetByID .
func (r *Repository) GetCategoryByID(id string) (models.Category, error) {
	var category models.Category
	err := r.CategoryCol.Find(bson.M{"CategoryID": id}).One(&category)
	return category, err
}

//Search by Name .
func (r *Repository) SearchCategoryByName(name string) ([]models.Category, error) {
	var listCategory []models.Category
	err := r.CategoryCol.Find(bson.M{"Name": bson.RegEx{name, ""}}).All(&listCategory)

	return listCategory, err
}

//Search by ID .
func (r *Repository) SearchCategoryByID(id string) ([]models.Category, error) {
	var listCategory []models.Category
	err := r.CategoryCol.Find(bson.M{"CategoryID": bson.RegEx{id, ""}}).All(&listCategory)

	return listCategory, err
}

//Update .
func (r *Repository) UpdateCategory(category *models.Category) error {
	err := r.CategoryCol.Update(bson.M{"CategoryID": category.CategoryID},
		bson.M{"$set": bson.M{
			"Name":   category.Name,
			"Image":  category.Image,
			"Status": category.Status,
		}})
	return err
}

//DeleteOne .
func (r *Repository) DeleteOneCategory(id string) error {
	err := r.CategoryCol.Update(bson.M{"CategoryID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	// Disable all Food of this Category
	r.FoodCol.UpdateAll(bson.M{"CategoryID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	// Remove all Menu Details belongs to this Category
	r.MenuDetailCol.RemoveAll(bson.M{"CategoryID": id})

	return err
}
