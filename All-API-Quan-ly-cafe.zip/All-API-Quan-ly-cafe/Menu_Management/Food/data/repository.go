package data

import "gopkg.in/mgo.v2"

type (
	//Repository .
	Repository struct {
		CategoryCol   *mgo.Collection
		FoodCol       *mgo.Collection
		MenuDetailCol *mgo.Collection
	}
)
