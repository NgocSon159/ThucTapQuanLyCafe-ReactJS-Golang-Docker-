package main

import (
	"Project/Menu_Management/Food/common"
	"Project/Menu_Management/Food/controllers"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gorilla/mux"
	. "github.com/smartystreets/goconvey/convey"
)

func TestCreateOneFoodEndPoint_Success(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/food", controllers.CreateOneFoodEndPoint).Methods("POST")

	common.StartUp()

	foodJSON := `{"data":{
        "FoodID": "FO050",
        "Name": "Test Food",
        "Price": 59000,
        "Size": "Medium",
        "CategoryID": "CA001"
    }}`

	Convey("Given a HTTP POST request for /food", t, func() {
		req := httptest.NewRequest("POST", "/food", strings.NewReader(foodJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 201", func() {
				So(resp.Code, ShouldEqual, 201)
			})
		})

		if resp.Code != 201 {
			t.Errorf("HTTP Status expected: 201, got: %d", resp.Code)
		}
	})
}

func TestCreateOneFoodEndPoint_Exist(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/food", controllers.CreateOneFoodEndPoint).Methods("POST")

	common.StartUp()

	foodJSON := `{"data":{
        "FoodID": "FO050",
        "Name": "Test Food",
        "Price": 59000,
        "Size": "Medium",
        "CategoryID": "CA001"
    }}`

	Convey("Given a HTTP POST request for /food", t, func() {
		req := httptest.NewRequest("POST", "/food", strings.NewReader(foodJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 500", func() {
				So(resp.Code, ShouldEqual, 500)
			})
		})

		if resp.Code != 500 {
			t.Errorf("HTTP Status expected: 500, got: %d", resp.Code)
		}
	})
}

func TestGetAllFoodEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/food", controllers.GetAllFoodEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /food", t, func() {
		req := httptest.NewRequest("GET", "/food", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestGetFoodByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/food/{id}", controllers.GetFoodByIDEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /food/{id}", t, func() {
		req := httptest.NewRequest("GET", "/food/FO050", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestUpdateFoodEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/food/{id}", controllers.UpdateFoodEndPoint).Methods("PUT")

	common.StartUp()

	foodJSON := `{"data":{
        "FoodID": "FO050",
        "Name": "Test Food changed",
        "Price": 60000,
        "Size": "Medium",
        "CategoryID": "CA001",
		"Status": true
    }}`

	Convey("Given a HTTP PUT request for /food/{id}", t, func() {
		req := httptest.NewRequest("PUT", "/food/FO050", strings.NewReader(foodJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestDeleteFoodByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/food/{id}", controllers.DeleteFoodByIDEndPoint).Methods("DELETE")

	common.StartUp()

	Convey("Given a HTTP DELETE request for /food/{id}", t, func() {
		req := httptest.NewRequest("DELETE", "/food/FO050", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 204", func() {
				So(resp.Code, ShouldEqual, 204)
			})
		})

		if resp.Code != 204 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}
