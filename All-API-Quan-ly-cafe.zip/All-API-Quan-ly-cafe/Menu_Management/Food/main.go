package main

import (
	"log"
	"net/http"

	"Project/Menu_Management/Food/common"
	"Project/Menu_Management/Food/routers"
)

func main() {
	common.StartUp()

	router := routers.InitRouter()

	server := &http.Server{
		Addr:    common.AppConfig.Server,
		Handler: router,
	}

	log.Println("Listening...")
	server.ListenAndServe()
}
