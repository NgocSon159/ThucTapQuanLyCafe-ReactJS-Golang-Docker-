package models

import (
	"time"

	"gopkg.in/mgo.v2/bson"
)

type (
	//Category Model
	Category struct {
		ID         bson.ObjectId `bson:"_id,omitempty"`
		CategoryID string        `bson:"CategoryID"`
		Name       string        `bson:"Name"`
		Image      string        `bson:"Image"`
		CreatedOn  time.Time     `bson:"CreatedOn"`
		Status     bool          `bson:"Status"`
	}

	//Food Model
	Food struct {
		ID         bson.ObjectId `bson:"_id,omitempty"`
		FoodID     string        `bson:"FoodID"`
		Name       string        `bson:"Name"`
		Price      int           `bson:"Price"`
		Size       string        `bson:"Size"`
		CreatedOn  time.Time     `bson:"CreatedOn"`
		CategoryID string        `bson:"CategoryID"`
		Status     bool          `bson:"Status"`
	}
)
