package controllers

import "Project/Menu_Management/Food/models"

type (
	//CategoriesResource .
	CategoriesResource struct {
		Data []models.Category `json:"data"`
	}

	//CategoryResource .
	CategoryResource struct {
		Data models.Category `json:"data"`
	}

	//FoodsResource .
	FoodsResource struct {
		Data []models.Food `json:"data"`
	}

	//FoodResource .
	FoodResource struct {
		Data models.Food `json:"data"`
	}
)
