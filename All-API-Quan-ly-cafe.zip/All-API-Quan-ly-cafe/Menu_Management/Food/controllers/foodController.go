package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"Project/Menu_Management/Food/common"
	"Project/Menu_Management/Food/data"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

// CreateOneFoodEndPoint .
func CreateOneFoodEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource FoodResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Food data", 500)
		return
	}

	food := &dataResource.Data
	context := NewContext()
	defer context.Close()

	foodcol := context.DbCollection("Food")
	categorycol := context.DbCollection("Categories")
	repo := &data.Repository{CategoryCol: categorycol, FoodCol: foodcol}

	err = repo.CreateOneFood(food)
	if nil != err {
		common.DisplayAppError(w, errors.New("Invalid"), err.Error(), 500)
		return
	}
	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

// GetAllFoodEndPoint .
func GetAllFoodEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	foodcol := context.DbCollection("Food")
	repo := &data.Repository{FoodCol: foodcol}

	foods := repo.GetAllFood()
	j, err := json.Marshal(FoodsResource{Data: foods})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// GetFoodByIDEndPoint .
func GetFoodByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	foodcol := context.DbCollection("Food")
	repo := &data.Repository{FoodCol: foodcol}

	food, err := repo.GetFoodByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(food)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// UpdateFoodEndPoint .
func UpdateFoodEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource FoodResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Employee data", 500)
		return
	}

	food := &dataResource.Data
	food.FoodID = id

	context := NewContext()
	defer context.Close()

	foodcol := context.DbCollection("Food")
	menudetailcol := context.DbCollection("MenuDetails")
	repo := &data.Repository{FoodCol: foodcol, MenuDetailCol: menudetailcol}

	if err := repo.UpdateFood(food); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

// DeleteFoodByIDEndPoint .
func DeleteFoodByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	foodcol := context.DbCollection("Food")
	menudetailcol := context.DbCollection("MenuDetails")
	repo := &data.Repository{FoodCol: foodcol, MenuDetailCol: menudetailcol}

	if err := repo.DeleteOneFood(id); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

// Search Food by Name .
func SearchFoodByNameEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	name := vars["name"]

	context := NewContext()
	defer context.Close()

	foodcol := context.DbCollection("Food")
	repo := &data.Repository{FoodCol: foodcol}

	listFood, err := repo.SearchFoodByName(name)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(listFood)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}
