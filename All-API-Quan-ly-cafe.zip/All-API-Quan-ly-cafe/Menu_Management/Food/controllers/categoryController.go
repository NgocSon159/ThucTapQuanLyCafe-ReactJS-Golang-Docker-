package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"Project/Menu_Management/Food/common"
	"Project/Menu_Management/Food/data"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

// CreateOneCategoryEndPoint .
func CreateOneCategoryEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource CategoryResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Categories data", 500)
		return
	}

	category := &dataResource.Data
	context := NewContext()
	defer context.Close()

	categorycol := context.DbCollection("Categories")
	repo := &data.Repository{CategoryCol: categorycol}

	err = repo.CreateOneCategory(category)
	if nil != err {
		common.DisplayAppError(w, errors.New("Invalid"), err.Error(), 500)
		return
	}
	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

// GetAllCategoriesEndPoint .
func GetAllCategoriesEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	categorycol := context.DbCollection("Categories")
	repo := &data.Repository{CategoryCol: categorycol}

	categories := repo.GetAllCategories()
	j, err := json.Marshal(CategoriesResource{Data: categories})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// GetCategoryByIDEndPoint .
func GetCategoryByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	categorycol := context.DbCollection("Categories")
	repo := &data.Repository{CategoryCol: categorycol}

	category, err := repo.GetCategoryByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(category)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// UpdateCategoryEndPoint .
func UpdateCategoryEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource CategoryResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Employee data", 500)
		return
	}

	category := &dataResource.Data
	category.CategoryID = id

	context := NewContext()
	defer context.Close()

	categorycol := context.DbCollection("Categories")
	repo := &data.Repository{CategoryCol: categorycol}

	if err := repo.UpdateCategory(category); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

// DeleteCategoryByIDEndPoint .
func DeleteCategoryByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	categorycol := context.DbCollection("Categories")
	foodcol := context.DbCollection("Food")
	menudetailcol := context.DbCollection("MenuDetails")
	repo := &data.Repository{CategoryCol: categorycol, FoodCol: foodcol, MenuDetailCol: menudetailcol}

	if err := repo.DeleteOneCategory(id); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

// Search Categories by Name .
func SearchCategoryByNameEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	name := vars["name"]

	context := NewContext()
	defer context.Close()

	categorycol := context.DbCollection("Categories")
	repo := &data.Repository{CategoryCol: categorycol}

	listcategory, err := repo.SearchCategoryByName(name)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(listcategory)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}
