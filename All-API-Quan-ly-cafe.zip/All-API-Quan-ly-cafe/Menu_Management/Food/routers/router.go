package routers

import "github.com/gorilla/mux"

//InitRouter .
func InitRouter() *mux.Router {
	router := mux.NewRouter().StrictSlash(false)

	router = SetCategoriesRouters(router)
	router = SetFoodRouters(router)
	return router
}
