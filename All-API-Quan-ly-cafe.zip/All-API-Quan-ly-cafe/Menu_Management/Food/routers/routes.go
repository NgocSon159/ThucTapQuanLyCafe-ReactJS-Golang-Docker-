package routers

import (
	"Project/Menu_Management/Food/controllers"

	"github.com/gorilla/mux"
)

// SetCategoriesRouters .
func SetCategoriesRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/categories", controllers.GetAllCategoriesEndPoint).Methods("GET")
	router.HandleFunc("/categories/{id}", controllers.GetCategoryByIDEndPoint).Methods("GET")
	router.HandleFunc("/categories", controllers.CreateOneCategoryEndPoint).Methods("POST")
	router.HandleFunc("/categories/{id}", controllers.UpdateCategoryEndPoint).Methods("PUT")
	router.HandleFunc("/categories/{id}", controllers.DeleteCategoryByIDEndPoint).Methods("DELETE")
	router.HandleFunc("/categories/search/{name}", controllers.SearchCategoryByNameEndPoint).Methods("GET")

	return router
}

// SetFoodRouters .
func SetFoodRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/food", controllers.GetAllFoodEndPoint).Methods("GET")
	router.HandleFunc("/food/{id}", controllers.GetFoodByIDEndPoint).Methods("GET")
	router.HandleFunc("/food", controllers.CreateOneFoodEndPoint).Methods("POST")
	router.HandleFunc("/food/{id}", controllers.UpdateFoodEndPoint).Methods("PUT")
	router.HandleFunc("/food/{id}", controllers.DeleteFoodByIDEndPoint).Methods("DELETE")
	router.HandleFunc("/food/search/{name}", controllers.SearchFoodByNameEndPoint).Methods("GET")

	return router
}
