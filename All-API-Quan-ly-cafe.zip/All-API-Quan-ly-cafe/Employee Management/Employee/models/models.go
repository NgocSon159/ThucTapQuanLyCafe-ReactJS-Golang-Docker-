package models

import (
	"time"

	"gopkg.in/mgo.v2/bson"
)

type (
	//Employee Model
	Employee struct {
		ID          bson.ObjectId `bson:"_id,omitempty" json:"id"`
		EmployeeID  string        `bson:"EmployeeID"`
		Name        string        `bson:"Name"`
		Birthday    time.Time     `bson:"Birthday"`
		PhoneNumber string        `bson:"PhoneNumber"`
		Identity    string        `bson:"Identity"`
		Address     string        `bson:"Address"`
		Email       string        `bson:"Email"`
		DateStart   time.Time     `bson:"DateStart"`
		DateEnd     time.Time     `bson:"DateEnd"`
		Image       string        `bson:"Image"`
		Status      bool          `bson:"Status"`
	}
)
