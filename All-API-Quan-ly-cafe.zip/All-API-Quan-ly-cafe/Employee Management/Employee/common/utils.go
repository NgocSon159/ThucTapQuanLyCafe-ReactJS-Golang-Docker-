package common

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"time"

	"gopkg.in/mgo.v2"
)

type (
	appError struct {
		Error      string `json:"error"`
		Message    string `json:"message"`
		HTTPStatus int    `json:"Status"`
	}
	errorResource struct {
		Data appError `json:"data"`
	}
	configuration struct {
		Server, MongoDBHost, DBUser, DBPwd, Database string
	}
)

//AppConfig .
var AppConfig configuration
var session *mgo.Session

func initConfig() {
	file, err := os.Open("common/config.json")
	defer file.Close()
	if err != nil {
		log.Fatalf("[loadConfig]: %s\n", err)
	}
	decoder := json.NewDecoder(file)
	AppConfig = configuration{}
	err = decoder.Decode(&AppConfig)
	if nil != err {
		log.Fatalf("[loadAppConfig]: %s\n", err)
	}
	loadConfigFromEnvironment(&AppConfig)
}

func loadConfigFromEnvironment(appConfig *configuration) {
	server, ok := os.LookupEnv("SERVER")
	if ok {
		appConfig.Server = server
		log.Printf("[INFO]: Server information loaded from env.")
	}

	mongodbHost, ok := os.LookupEnv("MONGODB_HOST")
	if ok {
		appConfig.MongoDBHost = mongodbHost
		log.Printf("[INFO]: MongoDB host information loaded from env.")
	}

	mongodbUser, ok := os.LookupEnv("MONGODB_USER")
	if ok {
		appConfig.DBUser = mongodbUser
		log.Printf("[INFO]: MongoDB user information loaded from env.")
	}

	mongodbPwd, ok := os.LookupEnv("MONGODB_PWD")
	if ok {
		appConfig.DBPwd = mongodbPwd
		log.Printf("[INFO]: MongoDB password information loaded from env.")
	}

	database, ok := os.LookupEnv("MONGODB_DATABASE")
	if ok {
		appConfig.Database = database
		log.Printf("[INFO]: MongoDB database information loaded from env.")
	}
}

//DisplayAppError .
func DisplayAppError(w http.ResponseWriter, handleError error, message string, code int) {
	errObj := appError{
		Error:      handleError.Error(),
		Message:    message,
		HTTPStatus: code,
	}
	log.Printf("[AppError]: %s\n", handleError)
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	if j, err := json.Marshal(errorResource{Data: errObj}); err == nil {
		w.Write(j)
	}
}

//GetSession .
func GetSession() *mgo.Session {
	if nil == session {
		var err error
		session, err = mgo.DialWithInfo(&mgo.DialInfo{
			Addrs:    []string{AppConfig.MongoDBHost},
			Username: AppConfig.DBUser,
			Password: AppConfig.DBPwd,
			Timeout:  60 * time.Second,
		})
		if nil != err {
			log.Fatalf("[GetSession: %s\n", err)
		}
	}
	return session
}

func createDbSession() {
	var err error
	session, err = mgo.DialWithInfo(&mgo.DialInfo{
		Addrs:    []string{AppConfig.MongoDBHost},
		Username: AppConfig.DBUser,
		Password: AppConfig.DBPwd,
		Timeout:  60 * time.Second,
	})
	if nil != err {
		log.Fatalf("[createDbSession]: %s\n", err)
	}
}
