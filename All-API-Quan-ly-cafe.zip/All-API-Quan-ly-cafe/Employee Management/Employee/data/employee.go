package data

import (
	"errors"
	"log"

	"github.com/User/Employee/models"

	"gopkg.in/mgo.v2/bson"
)

//CreateOneEmployee .
func (r *Repository) CreateOneEmployee(employee *models.Employee) error {
	checkExist, _ := r.EmployeeCol.Find(bson.M{"EmployeeID": employee.EmployeeID}).Count()

	if checkExist == 0 {
		objid := bson.NewObjectId()
		employee.ID = objid
		employee.Status = true

		err := r.EmployeeCol.Insert(&employee)
		return err
	}

	return errors.New("Employee already existed")
}

//GetAllEmployees .
func (r *Repository) GetAllEmployees() []models.Employee {
	var employees []models.Employee
	iter := r.EmployeeCol.Find(bson.M{"Status": true}).Iter()
	result := models.Employee{}
	for iter.Next(&result) {
		employees = append(employees, result)
	}
	return employees
}

//GetEmployeeByID .
func (r *Repository) GetEmployeeByID(id string) (models.Employee, error) {
	var employee models.Employee
	err := r.EmployeeCol.Find(bson.M{"EmployeeID": id}).One(&employee)
	log.Println(employee)
	return employee, err
}

//UpdateEmployee .
func (r *Repository) UpdateEmployee(employee *models.Employee) error {
	err := r.EmployeeCol.Update(bson.M{"EmployeeID": employee.EmployeeID},
		bson.M{"$set": bson.M{
			"Name":        employee.Name,
			"Birthday":    employee.Birthday,
			"PhoneNumber": employee.PhoneNumber,
			"Identity":    employee.Identity,
			"Address":     employee.Address,
			"Email":       employee.Email,
			"DateStart":   employee.DateStart,
			"DateEnd":     employee.DateEnd,
			"Image":       employee.Image,
			"Status":      employee.Status,
		}})
	return err
}

//DeleteOneEmployee .
func (r *Repository) DeleteOneEmployee(id string) error {
	err := r.EmployeeCol.Update(bson.M{"EmployeeID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})
	return err
}

/*
//DeleteAll .
func (r *Repository) DeleteAllEmployees() error {
	iter := r.EmployeeCol.Find(nil).Sort("priority", "EmployeeID").Iter()
	result := models.Employee{}
	var err error
	for iter.Next(&result) {
		err = r.EmployeeCol.Update(bson.M{"EmployeeID": result.EmployeeID},
			bson.M{"$set": bson.M{
				"Status": false,
			}})
	}
	return err
}*/
