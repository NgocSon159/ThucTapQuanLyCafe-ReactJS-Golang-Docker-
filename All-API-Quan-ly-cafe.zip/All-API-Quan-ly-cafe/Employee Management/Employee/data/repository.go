package data

import "gopkg.in/mgo.v2"

type (
	//Repository .
	Repository struct {
		EmployeeCol *mgo.Collection
	}
)
