package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"github.com/User/Employee/common"
	"github.com/User/Employee/data"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

//CreateOneEmployee .
func CreateOneEmployeeEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource EmployeeResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Employee data", 500)
		return
	}
	employee := &dataResource.Data
	context := NewContext()
	defer context.Close()

	employeecol := context.DbCollection("Employees")
	repo := &data.Repository{EmployeeCol: employeecol}

	err = repo.CreateOneEmployee(employee)
	if nil != err {
		common.DisplayAppError(w, errors.New("Invalid"), err.Error(), 500)
		return
	}
	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetAllEmployees .
func GetAllEmployeesEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()

	employeecol := context.DbCollection("Employees")
	repo := &data.Repository{EmployeeCol: employeecol}

	employees := repo.GetAllEmployees()
	j, err := json.Marshal(EmployeesResource{Data:employees})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetEmployeeByID .
func GetEmployeeByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	employeecol := context.DbCollection("Employees")
	repo := &data.Repository{EmployeeCol: employeecol}

	employee, err := repo.GetEmployeeByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(employee)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdateEmployee .
func UpdateEmployeeEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource EmployeeResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Employee data", 500)
		return
	}

	employee := &dataResource.Data
	employee.EmployeeID = id

	context := NewContext()
	defer context.Close()

	employeecol := context.DbCollection("Employees")
	repo := &data.Repository{EmployeeCol: employeecol}

	if err := repo.UpdateEmployee(employee); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

//DeleteEmployeeByID .
func DeleteEmployeeByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	employeecol := context.DbCollection("Employees")
	repo := &data.Repository{EmployeeCol: employeecol}

	if err := repo.DeleteOneEmployee(id); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
