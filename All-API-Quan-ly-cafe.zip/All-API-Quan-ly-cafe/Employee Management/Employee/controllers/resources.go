package controllers

import "github.com/User/Employee/models"

type (
	//EmployeesResource .
	EmployeesResource struct {
		Data []models.Employee `json:"data"`
	}

	//EmployeeResource .
	EmployeeResource struct {
		Data models.Employee `json:"data"`
	}
)
