package routers

import (
	"github.com/User/Employee/controllers"

	"github.com/gorilla/mux"
)

//SetRouters .
func SetRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/employees", controllers.GetAllEmployeesEndPoint).Methods("GET")
	router.HandleFunc("/employees/{id}", controllers.GetEmployeeByIDEndPoint).Methods("GET")
	router.HandleFunc("/employees", controllers.CreateOneEmployeeEndPoint).Methods("POST")
	router.HandleFunc("/employees/{id}", controllers.UpdateEmployeeEndPoint).Methods("PUT")
	router.HandleFunc("/employees/{id}", controllers.DeleteEmployeeByIDEndPoint).Methods("DELETE")
	return router
}
