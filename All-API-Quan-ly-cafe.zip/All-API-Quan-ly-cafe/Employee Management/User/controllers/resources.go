package controllers

import (
	"github.com/User/User/models"
)

//Models for JSON resources

type (
	//UseResource .
	UserResource struct {
		Data models.User `json:"data"`
	}
	//UsersResource .
	UsersResource struct {
		Data []models.User `json:"data"`
	}
	//UserRegisterResource .
	UserRegisterResource struct {
		Data UserRegister `json:"data"`
	}
	//UserLoginResource .
	UserLoginResource struct {
		Data UserLogin `json:"data"`
	}
	//AuthUserResource .
	AuthUserResource struct {
		Data AuthUserModel `json:"data"`
	}
	//UserRegister .
	UserRegister struct {
		Username   string `bson:"Username"`
		Password   string `bson:"Password"`
		EmployeeID string `bson:"EmployeeID"`
		RoleID     string `bson:"RoleID"`
		Status     bool   `bson:"Status"`
	}
	//UserLogin .
	UserLogin struct {
		Username string `bson:"Username"`
		Password string `bson:"Password"`
	}
	//AuthUserModel .
	AuthUserModel struct {
		User  models.User `json:"user"`
		Token string      `json:"token"`
	}
)
