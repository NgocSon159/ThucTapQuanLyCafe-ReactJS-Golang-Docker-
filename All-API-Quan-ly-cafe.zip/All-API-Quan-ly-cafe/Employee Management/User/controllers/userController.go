package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/User/User/common"
	"github.com/User/User/data"
	"github.com/User/User/models"
	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

// Register add a new User document
// Handler for HTTP Post - "/users/register"
func Register(w http.ResponseWriter, r *http.Request) {
	var dataResource UserRegisterResource
	// Decode the incoming User json
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if err != nil {
		common.DisplayAppError(w, err, "Invalid User data", 500)
		return
	}
	userRegister := &dataResource.Data
	context := NewContext()
	defer context.Close()
	usercol := context.DbCollection("Users")
	repo := &data.Repository{Usercol: usercol}
	user := &models.User{
		Username:   userRegister.Username,
		EmployeeID: userRegister.EmployeeID,
		RoleID:     userRegister.RoleID,
	}

	// Insert User document
	repo.Register(user, userRegister.Password)
	j, err := json.Marshal(dataResource)
	if err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

// Login authenticates the HTTP request with username and apssword
// Handler for HTTP Post - "/users/login"
func Login(w http.ResponseWriter, r *http.Request) {
	var dataResource UserLoginResource
	var token string
	// Decode the incoming Login json
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if err != nil {
		common.DisplayAppError(w, err, "Invalid Login data", 500)
		return
	}

	userLogin := dataResource.Data
	context := NewContext()
	defer context.Close()
	usercol := context.DbCollection("Users")
	repo := &data.Repository{Usercol: usercol}
	// Authenticate the login user
	user, err := repo.Login(userLogin.Username, userLogin.Password)
	if err != nil {
		common.DisplayAppError(w, err, "Incorrect username or password", 401)
		return
	}
	// Generate JWT token
	token, err = common.GenerateJWT(user.Username, user.RoleID)
	if err != nil {
		common.DisplayAppError(w, err, "Eror while generating the access token", 500)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	// Clean-up the hashpassword to eliminate it from response JSON
	user.HashPassword = nil
	authUser := AuthUserModel{
		User:  user,
		Token: token,
	}
	j, err := json.Marshal(AuthUserResource{Data: authUser})
	if err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetAllUsersEndPoint .
func GetAllUsersEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()

	usercol := context.DbCollection("Users")
	repo := &data.Repository{Usercol: usercol}

	users := repo.GetAllUsers()
	j, err := json.Marshal(UsersResource{Data: users})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetUserByUsernameEndPoint .
func GetUserByUsernameEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	username := vars["id"]

	context := NewContext()
	defer context.Close()

	usercol := context.DbCollection("Users")
	repo := &data.Repository{Usercol: usercol}

	user, err := repo.GetUserByUsername(username)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(user)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdateUserEndPoint .
func UpdateUserEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	username := vars["id"]

	var dataResource UserRegisterResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid User data", 500)
		return
	}

	userUpdate := &dataResource.Data
	userUpdate.Username = username
	context := NewContext()
	defer context.Close()

	usercol := context.DbCollection("Users")
	repo := &data.Repository{Usercol: usercol}
	user := &models.User{
		Username:   userUpdate.Username,
		EmployeeID: userUpdate.EmployeeID,
		RoleID:     userUpdate.RoleID,
		Status:     userUpdate.Status,
	}
	if err := repo.UpdateUser(user, userUpdate.Password); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

//DeleteUserByIDEndPoint .
func DeleteUserByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	usercol := context.DbCollection("Users")
	repo := &data.Repository{Usercol: usercol}

	if err := repo.DeleteOneUser(id); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
