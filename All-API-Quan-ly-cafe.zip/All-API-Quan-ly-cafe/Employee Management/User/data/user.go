package data

import (
	"github.com/User/User/models"
	"golang.org/x/crypto/bcrypt"
	"gopkg.in/mgo.v2/bson"
)

//Register .
func (r *Repository) Register(user *models.User, password string) error {
	user.ID = bson.NewObjectId()
	hpass, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	user.HashPassword = hpass
	user.Status = true
	err = r.Usercol.Insert(user)
	return err
}

// Login .
func (r *Repository) Login(username, password string) (models.User, error) {
	var user models.User
	err := r.Usercol.Find(bson.M{"Username": username}).One(&user)
	if err != nil {
		return models.User{}, err
	}
	// Validate password
	err = bcrypt.CompareHashAndPassword(user.HashPassword, []byte(password))
	if err != nil {
		return models.User{}, err
	}
	return user, nil

}

//GetAll .
func (r *Repository) GetAllUsers() []models.User {
	var users []models.User
	iter := r.Usercol.Find(bson.M{"Status": true}).Iter()
	result := models.User{}
	for iter.Next(&result) {
		users = append(users, result)
	}
	return users
}

//GetByName .
func (r *Repository) GetUserByUsername(username string) (models.User, error) {
	var user models.User
	err := r.Usercol.Find(bson.M{"Username": username}).One(&user)
	return user, err
}

//Update .
func (r *Repository) UpdateUser(user *models.User, password string) error {
	hpass, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	err = r.Usercol.Update(bson.M{"Username": user.Username},
		bson.M{"$set": bson.M{
			"HashPassword": hpass,
			"EmployeeID":   user.EmployeeID,
			"RoleID":       user.RoleID,
			"Status":       user.Status,
		}})
	return err
}

//DeleteOneUser .
func (r *Repository) DeleteOneUser(username string) error {
	err := r.Usercol.Update(bson.M{"Username": username},
		bson.M{"$set": bson.M{
			"Status": false,
		}})
	return err
}
