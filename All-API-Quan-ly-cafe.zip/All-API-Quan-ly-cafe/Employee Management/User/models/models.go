package models

import (
	"gopkg.in/mgo.v2/bson"
)

type (

	//User .
	User struct {
		ID           bson.ObjectId `bson:"_id,omitempty" json:"id"`
		Username     string        `bson:"Username"`
		HashPassword []byte        `bson:"HashPassword" json:"HashPassword,omitempty"`
		EmployeeID   string        `bson:"EmployeeID"`
		RoleID       string        `bson:"RoleID"`
		Status       bool          `bson:"Status"`
	}
)
