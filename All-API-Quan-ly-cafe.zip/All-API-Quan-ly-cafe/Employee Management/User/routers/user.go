package routers

import (
	"github.com/User/User/controllers"
	"github.com/gorilla/mux"
)

//SetUsersRoutes .
func SetUsersRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/register", controllers.Register).Methods("POST")
	router.HandleFunc("/login", controllers.Login).Methods("POST")
	router.HandleFunc("/users", controllers.GetAllUsersEndPoint).Methods("GET")
	router.HandleFunc("/users/{id}", controllers.GetUserByUsernameEndPoint).Methods("GET")
	router.HandleFunc("/users/{id}", controllers.UpdateUserEndPoint).Methods("PUT")
	router.HandleFunc("/users/{id}", controllers.DeleteUserByIDEndPoint).Methods("DELETE")
	return router
}
