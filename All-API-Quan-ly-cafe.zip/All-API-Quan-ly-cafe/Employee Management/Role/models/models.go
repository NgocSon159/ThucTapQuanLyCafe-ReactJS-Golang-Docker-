package models

import (
	"gopkg.in/mgo.v2/bson"
)

type (
	//Role Model
	Role struct {
		ID          bson.ObjectId `bson:"_id,omitempty" json:"id"`
		RoleID      string        `bson:"RoleID"`
		Name        string        `bson:"Name"`
		Status      bool          `bson:"Status"`
		Permissions []Permission  `bson:"Permissions"`
	}
	//Permission Model
	Permission struct {
		ID             bson.ObjectId `bson:"_id,omitempty" json:"id"`
		PermissionID   string        `bson:"PermissionID"`
		PermissionType string        `bson:"PermissionType"`
		Description    string        `bson:"Description"`
		Status         bool          `bson:"Status"`
	}
)
