package controllers

import "github.com/User/Role/models"

type (
	//PermissionsResource .
	PermissionsResource struct {
		Data []models.Permission `json:"data"`
	}

	//PermissionResource .
	PermissionResource struct {
		Data models.Permission `json:"data"`
	}

	//RolesResource .
	RolesResource struct {
		Data []models.Role `json:"data"`
	}

	//RoleResource .
	RoleResource struct {
		Data models.Role `json:"data"`
	}
)
