package controllers

import (
	"github.com/User/Role/common"
	"github.com/User/Role/data"
	"encoding/json"
	"errors"
	"net/http"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

//CreateOneRole .
func CreateOneRoleEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource RoleResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Role data", 500)
		return
	}

	Role := &dataResource.Data

	context := NewContext()
	defer context.Close()

	rolecol := context.DbCollection("Roles")
	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{RoleCol: rolecol, PermissionCol: permissioncol}

	err = repo.CreateOneRole(Role)
	if nil != err {
		common.DisplayAppError(w, errors.New("Invalid"), err.Error(), 500)
		return
	}

	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

//GetAllRoles .
func GetAllRolesEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()

	rolecol := context.DbCollection("Roles")
	repo := &data.Repository{RoleCol: rolecol}

	Roles := repo.GetAllRoles()

	j, err := json.Marshal(RolesResource{Data: Roles})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetRoleByID .
func GetRoleByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	rolecol := context.DbCollection("Roles")
	repo := &data.Repository{RoleCol: rolecol}

	Role, err := repo.GetRoleByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}
	j, err := json.Marshal(Role)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdateRole .
func UpdateRoleEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource RoleResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Role data", 500)
		return
	}

	Role := &dataResource.Data
	Role.RoleID = id

	context := NewContext()
	defer context.Close()

	rolecol := context.DbCollection("Roles")
	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{RoleCol: rolecol, PermissionCol: permissioncol}

	if err := repo.UpdateRole(Role); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

//DeleteRoleByID .
func DeleteRoleByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	rolecol := context.DbCollection("Roles")
	repo := &data.Repository{RoleCol: rolecol}

	err := repo.DeleteOneRole(id)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}
