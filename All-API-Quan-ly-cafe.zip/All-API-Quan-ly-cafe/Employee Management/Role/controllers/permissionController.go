package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"github.com/User/Role/common"
	"github.com/User/Role/data"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

//CreateOnePermission .
func CreateOnePermissionEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource PermissionResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Permission data", 500)
		return
	}

	permission := &dataResource.Data

	context := NewContext()
	defer context.Close()

	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{PermissionCol: permissioncol}

	err = repo.CreateOnePermission(permission)
	if nil != err {
		common.DisplayAppError(w, errors.New("Invalid"), err.Error(), 500)
		return
	}

	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

//GetAllPermissions .
func GetAllPermissionsEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()

	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{PermissionCol: permissioncol}

	permissions := repo.GetAllPermissions()

	j, err := json.Marshal(PermissionsResource{Data: permissions})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetPermissionByID .
func GetPermissionByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{PermissionCol: permissioncol}

	permission, err := repo.GetPermissionByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}
	j, err := json.Marshal(permission)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdatePermission .
func UpdatePermissionEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource PermissionResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Permission data", 500)
		return
	}

	permission := &dataResource.Data
	permission.PermissionID = id

	context := NewContext()
	defer context.Close()
	rolecol := context.DbCollection("Roles")
	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{PermissionCol: permissioncol, RoleCol: rolecol}
	if err := repo.UpdatePermission(permission); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

//DeletePermissionByID .
func DeletePermissionByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	rolecol := context.DbCollection("Roles")
	permissioncol := context.DbCollection("Permissions")
	repo := &data.Repository{PermissionCol: permissioncol, RoleCol: rolecol}

	err := repo.DeleteOnePermission(id)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}
