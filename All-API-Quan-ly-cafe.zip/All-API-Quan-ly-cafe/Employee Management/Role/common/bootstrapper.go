package common

//StartUp .
func StartUp() {
	initConfig()
	initKeys()
	createDbSession()
}
