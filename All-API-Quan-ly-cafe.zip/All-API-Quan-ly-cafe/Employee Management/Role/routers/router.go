package routers

import "github.com/gorilla/mux"

//InitRouter .
func InitRouter() *mux.Router {
	router := mux.NewRouter().StrictSlash(false)

	router = SetPermissionRouters(router)
	
	router = SetRoleRouters(router)
	return router
}
