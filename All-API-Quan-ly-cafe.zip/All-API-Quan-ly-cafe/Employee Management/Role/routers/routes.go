package routers

import (
	"github.com/User/Role/controllers"
	"github.com/gorilla/mux"
)

//SetPermissionRouters .
func SetPermissionRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/permissions", controllers.GetAllPermissionsEndPoint).Methods("GET")
	router.HandleFunc("/permissions/{id}", controllers.GetPermissionByIDEndPoint).Methods("GET")
	router.HandleFunc("/permissions", controllers.CreateOnePermissionEndPoint).Methods("POST")
	router.HandleFunc("/permissions/{id}", controllers.UpdatePermissionEndPoint).Methods("PUT")
	router.HandleFunc("/permissions/{id}", controllers.DeletePermissionByIDEndPoint).Methods("DELETE")
	return router
}

//SetRoleRouters .
func SetRoleRouters(router *mux.Router) *mux.Router {
	/*roleRouter := mux.NewRouter()
	roleRouter.HandleFunc("/roles", controllers.GetAllRolesEndPoint).Methods("GET")
	roleRouter.HandleFunc("/roles/{id}", controllers.GetRoleByIDEndPoint).Methods("GET")
	roleRouter.HandleFunc("/roles", controllers.CreateOneRoleEndPoint).Methods("POST")
	roleRouter.HandleFunc("/roles/{id}", controllers.UpdateRoleEndPoint).Methods("PUT")
	roleRouter.HandleFunc("/roles/{id}", controllers.DeleteRoleByIDEndPoint).Methods("DELETE")
	router.PathPrefix("/roles").Handler(common.AuthorizeRequest(roleRouter))*/
	router.HandleFunc("/roles", controllers.GetAllRolesEndPoint).Methods("GET")
	router.HandleFunc("/roles/{id}", controllers.GetRoleByIDEndPoint).Methods("GET")
	router.HandleFunc("/roles", controllers.CreateOneRoleEndPoint).Methods("POST")
	router.HandleFunc("/roles/{id}", controllers.UpdateRoleEndPoint).Methods("PUT")
	router.HandleFunc("/roles/{id}", controllers.DeleteRoleByIDEndPoint).Methods("DELETE")
	return router
}
