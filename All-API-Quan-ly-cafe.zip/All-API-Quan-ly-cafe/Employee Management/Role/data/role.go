package data

import (
	"errors"

	"github.com/User/Role/models"

	"gopkg.in/mgo.v2/bson"
)

//CreateOneRole .
func (r *Repository) CreateOneRole(Role *models.Role) error {
	checkExist, _ := r.RoleCol.Find(bson.M{"RoleID": Role.RoleID}).Count()

	if checkExist == 0 {
		objid := bson.NewObjectId()
		Role.ID = objid
		Role.Status = true
		err := r.RoleCol.Insert(&Role)
		return err
	}

	return errors.New("Role already existed")
}

//GetAllRoles .
func (r *Repository) GetAllRoles() []models.Role {
	var Roles []models.Role
	iter := r.RoleCol.Find(bson.M{"Status": true}).Sort("RoleID").Iter()
	result := models.Role{}
	for iter.Next(&result) {
		Roles = append(Roles, result)
	}
	return Roles
}

//GetRoleByID .
func (r *Repository) GetRoleByID(id string) (models.Role, error) {
	var Role models.Role
	err := r.RoleCol.Find(bson.M{"RoleID": id}).One(&Role)
	return Role, err
}

//UpdateRole .
func (r *Repository) UpdateRole(Role *models.Role) error {
	err := r.RoleCol.Update(bson.M{"RoleID": Role.RoleID},
		bson.M{"$set": bson.M{
			"Name":        Role.Name,
			"Status":      Role.Status,
			"Permissions": Role.Permissions,
		}})
	return err
}

//DeleteOneRole .
func (r *Repository) DeleteOneRole(id string) error {
	err := r.RoleCol.Update(bson.M{"RoleID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})
	return err
}
