package data

import "gopkg.in/mgo.v2"

type (
	//Repository .
	Repository struct {
		RoleCol       *mgo.Collection
		PermissionCol *mgo.Collection
	}
)
