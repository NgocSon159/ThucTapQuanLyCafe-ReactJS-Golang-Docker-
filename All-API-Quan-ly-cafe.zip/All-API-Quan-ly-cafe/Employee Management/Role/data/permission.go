package data

import (
	"errors"

	"github.com/User/Role/models"

	"gopkg.in/mgo.v2/bson"
)

//CreateOnePermission .
func (r *Repository) CreateOnePermission(permission *models.Permission) error {
	checkExist, _ := r.PermissionCol.Find(bson.M{"PermissionID": permission.PermissionID}).Count()

	if checkExist == 0 {
		objid := bson.NewObjectId()
		permission.ID = objid
		permission.Status = true
		err := r.PermissionCol.Insert(&permission)
		return err
	}

	return errors.New("Permission already existed")
}

//GetAllPermissions .
func (r *Repository) GetAllPermissions() []models.Permission {
	var permissions []models.Permission
	iter := r.PermissionCol.Find(bson.M{"Status": true}).Sort("PermissionID").Iter()
	result := models.Permission{}
	for iter.Next(&result) {
		permissions = append(permissions, result)
	}
	return permissions
}

//GetPermissionByID .
func (r *Repository) GetPermissionByID(id string) (models.Permission, error) {
	var permission models.Permission
	err := r.PermissionCol.Find(bson.M{"PermissionID": id}).One(&permission)
	return permission, err
}

//UpdatePermission .
func (r *Repository) UpdatePermission(permission *models.Permission) error {
	err := r.PermissionCol.Update(bson.M{"PermissionID": permission.PermissionID},
		bson.M{"$set": bson.M{
			"PermissionType": permission.PermissionType,
			"Description":    permission.Description,
			"Status":         permission.Status,
		}})
	r.RoleCol.UpdateAll(bson.M{"Permissions": bson.M{"$elemMatch": bson.M{"PermissionID": permission.PermissionID}}},
		bson.M{"$set": bson.M{
			"Permissions.$": permission,
		}})
	return err
}

//DeleteOnePermission .
func (r *Repository) DeleteOnePermission(id string) error {
	err := r.PermissionCol.Update(bson.M{"PermissionID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})
	if nil != err {
		return err
	}
	_, err = r.RoleCol.UpdateAll(bson.M{"Permissions": bson.M{"$elemMatch": bson.M{"PermissionID": id}}},
		bson.M{"$pull": bson.M{"Permissions": bson.M{"PermissionID": id}}})
	if nil != err {
		return err
	}
	return err
}
