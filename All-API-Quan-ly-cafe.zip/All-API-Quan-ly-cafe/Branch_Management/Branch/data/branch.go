package data

import (
	"Project/Branch_Management/Branch/models"
	"errors"

	"gopkg.in/mgo.v2/bson"
)

//CreateOne .
func (r *Repository) CreateOneBranch(branch *models.Branch) error {
	checkExist, _ := r.BranchCol.Find(bson.M{"BranchID": branch.BranchID}).Count()

	if checkExist == 0 {
		objid := bson.NewObjectId()
		branch.ID = objid
		branch.Status = true
		err := r.BranchCol.Insert(&branch)
		return err
	}

	return errors.New("Branch already existed")
}

//GetAll .
func (r *Repository) GetAllBranches() []models.Branch {
	var branches []models.Branch

	iter := r.BranchCol.Find(bson.M{"Status": true}).Sort("BranchID").Iter()
	result := models.Branch{}
	for iter.Next(&result) {
		branches = append(branches, result)
	}
	return branches
}

//GetByID .
func (r *Repository) GetBranchByID(id string) (models.Branch, error) {
	var branch models.Branch
	err := r.BranchCol.Find(bson.M{"BranchID": id}).One(&branch)
	return branch, err
}

//Search by Keyword .
func (r *Repository) SearchBranchByKeyword(searchString string) ([]models.Branch, error) {
	var listBranch []models.Branch
	err := r.BranchCol.Find(bson.M{"$or": []interface{}{bson.M{"Name": bson.RegEx{searchString, ""}}, bson.M{"PhoneNumber": bson.RegEx{searchString, ""}}, bson.M{"BranchID": bson.RegEx{searchString, ""}}}}).All(&listBranch)

	return listBranch, err
}

//Update .
func (r *Repository) UpdateBranch(branch *models.Branch) error {
	err := r.BranchCol.Update(bson.M{"BranchID": branch.BranchID},
		bson.M{"$set": bson.M{
			"Name":        branch.Name,
			"Address":     branch.Address,
			"PhoneNumber": branch.PhoneNumber,
			"NameWifi":    branch.NameWifi,
			"PassWifi":    branch.PassWifi,
			"Status":      branch.Status,
		}})
	return err
}

//DeleteOne .
func (r *Repository) DeleteOneBranch(id string) error {
	err := r.BranchCol.Update(bson.M{"BranchID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	// Disable all Menus of this Branch
	r.MenuCol.UpdateAll(bson.M{"BranchID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	return err
}
