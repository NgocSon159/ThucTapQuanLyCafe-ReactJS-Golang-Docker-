package data

import "gopkg.in/mgo.v2"

type (
	//Repository .
	Repository struct {
		BranchCol *mgo.Collection
		MenuCol   *mgo.Collection
	}
)
