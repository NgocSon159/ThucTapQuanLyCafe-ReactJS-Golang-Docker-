package controllers

import "Project/Branch_Management/Branch/models"

type (
	//BranchesResource .
	BranchesResource struct {
		Data []models.Branch `json:"data"`
	}

	//BranchResource .
	BranchResource struct {
		Data models.Branch `json:"data"`
	}
)
