package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"Project/Branch_Management/Branch/common"
	"Project/Branch_Management/Branch/data"

	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

// CreateOneBranchEndPoint .
func CreateOneBranchEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource BranchResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Branches data", 500)
		return
	}

	branch := &dataResource.Data
	context := NewContext()
	defer context.Close()

	branchcol := context.DbCollection("Branches")
	repo := &data.Repository{BranchCol: branchcol}

	err = repo.CreateOneBranch(branch)
	if nil != err {
		common.DisplayAppError(w, errors.New("Exist"), err.Error(), 500)
		return
	}
	j, err := json.Marshal(dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

// GetAllBranchesEndPoint .
func GetAllBranchesEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()

	branchcol := context.DbCollection("Branches")
	repo := &data.Repository{BranchCol: branchcol}

	branches := repo.GetAllBranches()
	j, err := json.Marshal(BranchesResource{Data: branches})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// GetBranchByIDEndPoint .
func GetBranchByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	branchcol := context.DbCollection("Branches")
	repo := &data.Repository{BranchCol: branchcol}

	branch, err := repo.GetBranchByID(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(branch)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

// UpdateBranchEndPoint .
func UpdateBranchEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	var dataResource BranchResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Employee data", 500)
		return
	}

	branch := &dataResource.Data
	branch.BranchID = id

	context := NewContext()
	defer context.Close()

	branchcol := context.DbCollection("Branches")
	repo := &data.Repository{BranchCol: branchcol}

	if err := repo.UpdateBranch(branch); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

// DeleteBranchByIDEndPoint .
func DeleteBranchByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	context := NewContext()
	defer context.Close()

	branchcol := context.DbCollection("Branches")
	menucol := context.DbCollection("Menus")
	repo := &data.Repository{BranchCol: branchcol, MenuCol: menucol}

	if err := repo.DeleteOneBranch(id); nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

// Search Branches by Keyword .
func SearchBranchByKeywordEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	searchString := vars["keyword"]

	context := NewContext()
	defer context.Close()

	branchcol := context.DbCollection("Branches")
	repo := &data.Repository{BranchCol: branchcol}

	listbranch, err := repo.SearchBranchByKeyword(searchString)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}

	j, err := json.Marshal(listbranch)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}
