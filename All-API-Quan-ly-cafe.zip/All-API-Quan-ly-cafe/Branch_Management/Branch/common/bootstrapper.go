package common

//StartUp .
func StartUp() {
	initConfig()
	createDbSession()
}
