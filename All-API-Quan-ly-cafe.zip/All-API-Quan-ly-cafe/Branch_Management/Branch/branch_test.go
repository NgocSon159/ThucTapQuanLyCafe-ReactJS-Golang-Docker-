package main

import (
	"Project/Branch_Management/Branch/common"
	"Project/Branch_Management/Branch/controllers"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/gorilla/mux"
	. "github.com/smartystreets/goconvey/convey"
)

func TestCreateOneBranchEndPoint_Success(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/branches", controllers.CreateOneBranchEndPoint).Methods("POST")

	common.StartUp()

	branchJSON := `{"data":{
        "BranchID": "BR007",
        "Name": "Test Branch 01",
        "Address": "114 Hồ Tùng Mậu, Q.1, TP.HCM",
        "PhoneNumber": "0123456789",
        "NameWifi": "TheAlley01",
        "PassWifi": "12345678"
    }}`

	Convey("Given a HTTP POST request for /branches", t, func() {
		req := httptest.NewRequest("POST", "/branches", strings.NewReader(branchJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 201", func() {
				So(resp.Code, ShouldEqual, 201)
			})
		})

		if resp.Code != 201 {
			t.Errorf("HTTP Status expected: 201, got: %d", resp.Code)
		}
	})
}

func TestCreateOneBranchEndPoint_Exist(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/branches", controllers.CreateOneBranchEndPoint).Methods("POST")

	common.StartUp()

	branchJSON := `{"data":{
        "BranchID": "BR007",
        "Name": "Test Branch 01",
        "Address": "114 Hồ Tùng Mậu, Q.1, TP.HCM",
        "PhoneNumber": "0123456789",
        "NameWifi": "TheAlley01",
        "PassWifi": "12345678"
    }}`

	Convey("Given a HTTP POST request for /branches", t, func() {
		req := httptest.NewRequest("POST", "/branches", strings.NewReader(branchJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 500", func() {
				So(resp.Code, ShouldEqual, 500)
			})
		})

		if resp.Code != 500 {
			t.Errorf("HTTP Status expected: 500, got: %d", resp.Code)
		}
	})
}

func TestGetAllBranchesEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/branches", controllers.GetAllBranchesEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /branches", t, func() {
		req := httptest.NewRequest("GET", "/branches", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestGetBranchByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/branches/{id}", controllers.GetBranchByIDEndPoint).Methods("GET")

	common.StartUp()

	Convey("Given a HTTP GET request for /branches/{id}", t, func() {
		req := httptest.NewRequest("GET", "/branches/BR007", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestUpdateBranchEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/branches/{id}", controllers.UpdateBranchEndPoint).Methods("PUT")

	common.StartUp()

	branchJSON := `{"data":{
        "Name": "Test 01 has changed",
        "Address": "114 Hồ Tùng Mậu, Q.1, TP.HCM",
        "PhoneNumber": "0123456789",
        "NameWifi": "kdfjgkdfjgk",
		"PassWifi": "jsjdkajsdj",
		"Status": true
    }}`

	Convey("Given a HTTP PUT request for /branches/{id}", t, func() {
		req := httptest.NewRequest("PUT", "/branches/BR007", strings.NewReader(branchJSON))

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 200", func() {
				So(resp.Code, ShouldEqual, 200)
			})
		})

		if resp.Code != 200 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}

func TestDeleteBranchByIDEndPoint(t *testing.T) {
	r := mux.NewRouter()

	r.HandleFunc("/branches/{id}", controllers.DeleteBranchByIDEndPoint).Methods("DELETE")

	common.StartUp()

	Convey("Given a HTTP DELETE request for /branches/{id}", t, func() {
		req := httptest.NewRequest("DELETE", "/branches/BR007", nil)

		resp := httptest.NewRecorder()

		Convey("When the request is handled by the Router", func() {
			r.ServeHTTP(resp, req)

			Convey("Then the response should be 204", func() {
				So(resp.Code, ShouldEqual, 204)
			})
		})

		if resp.Code != 204 {
			t.Errorf("HTTP Status expected: 200, got: %d", resp.Code)
		}
	})
}
