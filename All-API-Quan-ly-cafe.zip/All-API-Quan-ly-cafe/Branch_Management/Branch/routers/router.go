package routers

import "github.com/gorilla/mux"

//InitRouter .
func InitRouter() *mux.Router {
	router := mux.NewRouter().StrictSlash(false)

	router = SetBranchesRouters(router)
	return router
}
