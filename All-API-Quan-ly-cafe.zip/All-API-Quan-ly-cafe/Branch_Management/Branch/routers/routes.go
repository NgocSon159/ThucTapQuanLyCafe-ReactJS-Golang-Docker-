package routers

import (
	"Project/Branch_Management/Branch/controllers"

	"github.com/gorilla/mux"
)

// SetBranchesRouters .
func SetBranchesRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/branches", controllers.GetAllBranchesEndPoint).Methods("GET")
	router.HandleFunc("/branches/{id}", controllers.GetBranchByIDEndPoint).Methods("GET")
	router.HandleFunc("/branches", controllers.CreateOneBranchEndPoint).Methods("POST")
	router.HandleFunc("/branches/{id}", controllers.UpdateBranchEndPoint).Methods("PUT")
	router.HandleFunc("/branches/{id}", controllers.DeleteBranchByIDEndPoint).Methods("DELETE")
	router.HandleFunc("/branches/search/{keyword}", controllers.SearchBranchByKeywordEndPoint).Methods("GET")

	return router
}
