package main

import (
	"log"
	"net/http"

	"Project/Branch_Management/Branch/common"
	"Project/Branch_Management/Branch/routers"
)

func main() {
	common.StartUp()

	router := routers.InitRouter()

	server := &http.Server{
		Addr:    common.AppConfig.Server,
		Handler: router,
	}

	log.Println("Listening...")
	server.ListenAndServe()
}
