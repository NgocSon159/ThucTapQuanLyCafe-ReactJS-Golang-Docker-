package models

import (
	"gopkg.in/mgo.v2/bson"
)

type (
	//Branch Model
	Branch struct {
		ID          bson.ObjectId `bson:"_id,omitempty"`
		BranchID    string        `bson:"BranchID"`
		Name        string        `bson:"Name"`
		Address     string        `bson:"Address"`
		PhoneNumber string        `bson:"PhoneNumber"`
		NameWifi    string        `bson:"NameWifi"`
		PassWifi    string        `bson:"PassWifi"`
		Status      bool          `bson:"Status"`
	}
)
