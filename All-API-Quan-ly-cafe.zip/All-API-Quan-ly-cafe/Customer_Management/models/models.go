package models

import (
	"time"

	"gopkg.in/mgo.v2/bson"
)

type (
	Customer struct {
		ID          bson.ObjectId `bson:"_id,omitempty" json:"id"`
		PhoneNumber string        `bson:"PhoneNumber"`
		Name        string        `bson:"Name"`
		Birthday    time.Time     `bson:"Birthday"`
		Address     string        `bson:"Address"`
		CreateOn    time.Time     `bson:"CreateOn"`
		Point       int           `bson:"Point"`
		Rank        Rank          `bson:"Rank"`
	}

	Rank struct {
		ID       bson.ObjectId `bson:"_id,omitempty" json:"id"`
		RankID   string        `bson:"RankID"`
		Name     string        `bson:"Name"`
		Discount int           `bson:"Discount"`
		Point    int           `bson:"Point"`
		Status   bool          `bson:"Status"`
	}
)
