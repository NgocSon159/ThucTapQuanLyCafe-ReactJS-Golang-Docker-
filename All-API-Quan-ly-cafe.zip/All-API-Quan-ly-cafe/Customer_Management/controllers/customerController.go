package controllers

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"

	"github.com/Customer/common"
	"github.com/Customer/data"
	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

//CreateOneCustomerEndPoint .
func CreateOneCustomerEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource CustomerResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Customer data", 500)
		return
	}
	customer := &dataResource.Data
	context := NewContext()
	defer context.Close()
	customercol := context.DbCollection("Customers")
	rankcol := context.DbCollection("Ranks")
	repo := &data.Repository{Customercol: customercol, Rankcol: rankcol}
	err = repo.CreateOneCustomer(customer)
	if nil != err {
		common.DisplayAppError(w, errors.New("Exist"), err.Error(), 501)
		return
	}
	j, err := json.Marshal(dataResource)
	if err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 502)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

//GetAllCustomersEndPoint .
func GetAllCustomersEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	customercol := context.DbCollection("Customers")
	repo := &data.Repository{Customercol: customercol}
	customers := repo.GetAllCustomer()
	j, err := json.Marshal(CustomersResource{Data: customers})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetCustomerByPhoneEndPoint .
func GetCustomerByPhoneEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	context := NewContext()
	defer context.Close()
	customercol := context.DbCollection("Customers")
	repo := &data.Repository{Customercol: customercol}
	customer, err := repo.GetByPhoneCustomer(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}
	j, err := json.Marshal(customer)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdateCustomerEndPoint .
func UpdateCustomerEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	var dataResource CustomerResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Customer data", 500)
		return
	}
	customer := &dataResource.Data
	customer.PhoneNumber = id
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	customercol := context.DbCollection("Customers")
	repo := &data.Repository{Customercol: customercol, Rankcol: rankcol}
	if err := repo.UpdateCustomer(customer); err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

//AddPointByPhoneNumberEndPoint .
func AddPointByPhoneNumberEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	phonenumber := vars["id"]
	point := vars["point"]
	addpoint, _ := strconv.Atoi(point)
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	customercol := context.DbCollection("Customers")
	repo := &data.Repository{Customercol: customercol, Rankcol: rankcol}
	if err := repo.AddPointByPhoneNumber(phonenumber, addpoint); err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}
