package controllers

import "github.com/Customer/models"

type (

	//CustomersResource .
	CustomersResource struct {
		Data []models.Customer `json:"data"`
	}

	//CustomerResource .
	CustomerResource struct {
		Data models.Customer `json:"data"`
	}

	//RanksResource .
	RanksResource struct {
		Data []models.Rank `json:"data"`
	}

	//RankResource .
	RankResource struct {
		Data models.Rank `json:"data"`
	}
)
