package controllers

import (
	"encoding/json"
	"net/http"

	"github.com/Customer/common"
	"github.com/Customer/data"
	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

//CreateOneRankEndPoint .
func CreateOneRankEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource RankResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Rank data", 500)
		return
	}
	rank := &dataResource.Data
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	repo := &data.Repository{Rankcol: rankcol}
	repo.CreateOneRank(rank)
	j, err := json.Marshal(dataResource)
	if err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetAllRanksEndPoint .
func GetAllRanksEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	repo := &data.Repository{Rankcol: rankcol}
	ranks := repo.GetAllRank()
	j, err := json.Marshal(RanksResource{Data: ranks})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetRankByIDEndPoint .
func GetRankByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	repo := &data.Repository{Rankcol: rankcol}
	rank, err := repo.GetByIDRank(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}
	j, err := json.Marshal(rank)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdateRankEndPoint .
func UpdateRankEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	var dataResource RankResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Rank data", 500)
		return
	}
	rank := &dataResource.Data
	rank.RankID = id
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	customercol := context.DbCollection("Customers")
	repo := &data.Repository{Rankcol: rankcol, Customercol: customercol}
	if err := repo.UpdateRank(rank); err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

//DeleteRankByIDEndPoint .
func DeleteRankByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	context := NewContext()
	defer context.Close()
	rankcol := context.DbCollection("Ranks")
	repo := &data.Repository{Rankcol: rankcol}
	if err := repo.DeleteOneRank(id); err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
