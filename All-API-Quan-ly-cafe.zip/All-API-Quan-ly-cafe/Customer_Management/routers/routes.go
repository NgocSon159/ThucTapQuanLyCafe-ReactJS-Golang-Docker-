package routers

import (
	"github.com/Customer/controllers"
	"github.com/gorilla/mux"
)

//SetRouters .
func SetRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/customers", controllers.GetAllCustomersEndPoint).Methods("GET")
	router.HandleFunc("/customers/{id}", controllers.GetCustomerByPhoneEndPoint).Methods("GET")
	router.HandleFunc("/customers", controllers.CreateOneCustomerEndPoint).Methods("POST")
	router.HandleFunc("/customers/{id}", controllers.UpdateCustomerEndPoint).Methods("PUT")
	router.HandleFunc("/customers/{id}/{point}", controllers.AddPointByPhoneNumberEndPoint).Methods("POST")

	router.HandleFunc("/ranks", controllers.GetAllRanksEndPoint).Methods("GET")
	router.HandleFunc("/ranks/{id}", controllers.GetRankByIDEndPoint).Methods("GET")
	router.HandleFunc("/ranks", controllers.CreateOneRankEndPoint).Methods("POST")
	router.HandleFunc("/ranks/{id}", controllers.UpdateRankEndPoint).Methods("PUT")
	router.HandleFunc("/ranks/{id}", controllers.DeleteRankByIDEndPoint).Methods("DELETE")
	return router
}
