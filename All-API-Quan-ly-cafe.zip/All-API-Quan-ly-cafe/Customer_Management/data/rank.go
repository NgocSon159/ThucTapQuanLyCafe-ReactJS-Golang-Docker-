package data

import (
	"github.com/Customer/models"
	"gopkg.in/mgo.v2/bson"
)

//CreateOneRank .
func (r *Repository) CreateOneRank(rank *models.Rank) error {
	checkExist, _ := r.Rankcol.Find(bson.M{"RankID": rank.RankID}).Count()
	if checkExist == 0 {
		objid := bson.NewObjectId()
		rank.ID = objid
		rank.Status = true
		err := r.Rankcol.Insert(&rank)
		return err
	}
	return nil
}

//GetAllRank .
func (r *Repository) GetAllRank() []models.Rank {
	var ranks []models.Rank
	iter := r.Rankcol.Find(bson.M{"Status": true}).Sort("priority", "RankID").Iter()
	result := models.Rank{}
	for iter.Next(&result) {
		ranks = append(ranks, result)
	}
	return ranks
}

//GetByIDRank .
func (r *Repository) GetByIDRank(id string) (models.Rank, error) {
	var rank models.Rank
	err := r.Rankcol.Find(bson.M{"RankID": id}).One(&rank)
	return rank, err
}

//GetByPointRank .
func (r *Repository) GetByPointRank(point int) models.Rank {
	var rank models.Rank
	ranks := r.GetAllRank()
	for _, index := range ranks {
		if point >= index.Point {
			rank = index
		} else {
			break
		}
	}
	return rank
}

//UpdateRank .
func (r *Repository) UpdateRank(rank *models.Rank) error {
	err := r.Rankcol.Update(bson.M{"RankID": rank.RankID},
		bson.M{"$set": bson.M{
			"Name":     rank.Name,
			"Discount": rank.Discount,
			"Point":    rank.Point,
			"Status":   rank.Status,
		}})
	r.Customercol.UpdateAll(bson.M{"Rank.RankID": rank.RankID},
		bson.M{"$set": bson.M{
			"Rank": r.GetByPointRank(rank.Point),
		}})
	return err
}

//DeleteOneRank .
func (r *Repository) DeleteOneRank(id string) error {
	err := r.Rankcol.Update(bson.M{"RankID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})
		
	return err
}
