package data

import "gopkg.in/mgo.v2"

type (
	//Repository .
	Repository struct {
		Customercol *mgo.Collection
		Rankcol     *mgo.Collection
	}
)
