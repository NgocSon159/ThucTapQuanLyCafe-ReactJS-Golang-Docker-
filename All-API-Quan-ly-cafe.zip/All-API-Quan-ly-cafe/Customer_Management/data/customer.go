package data

import (
	"errors"
	"time"

	"github.com/Customer/models"
	"gopkg.in/mgo.v2/bson"
)

//CreateOneCustomer .
func (r *Repository) CreateOneCustomer(customer *models.Customer) error {
	count, _ := r.Customercol.Find(bson.M{"PhoneNumber": customer.PhoneNumber}).Count()
	if count == 0 {
		objid := bson.NewObjectId()
		customer.ID = objid
		customer.CreateOn = time.Now()
		customer.Rank = r.GetByPointRank(customer.Point)
		err := r.Customercol.Insert(&customer)
		return err
	}
	return errors.New("Customer already exist")
}

//GetAllCustomer .
func (r *Repository) GetAllCustomer() []models.Customer {
	var customers []models.Customer
	iter := r.Customercol.Find(nil).Iter()
	result := models.Customer{}
	for iter.Next(&result) {
		customers = append(customers, result)
	}

	return customers
}

//GetByPhoneCustomer .
func (r *Repository) GetByPhoneCustomer(phone string) (models.Customer, error) {
	var customer models.Customer
	err := r.Customercol.Find(bson.M{"PhoneNumber": phone}).One(&customer)
	return customer, err
}

//UpdateCustomer .
func (r *Repository) UpdateCustomer(customer *models.Customer) error {
	err := r.Customercol.Update(bson.M{"PhoneNumber": customer.PhoneNumber},
		bson.M{"$set": bson.M{
			"Name":     customer.Name,
			"Address":  customer.Address,
			"Birthday": customer.Birthday,
			"CreateOn": time.Now(),
			"Point":    customer.Point,
			"Rank":     r.GetByPointRank(customer.Point),
		}})
	return err
}

//AddPointByPhoneNumber .
func (r *Repository) AddPointByPhoneNumber(phonenumber string, addpoint int) error {
	var customer models.Customer
	r.Customercol.Find(bson.M{"PhoneNumber": phonenumber}).One(&customer)

	err := r.Customercol.Update(bson.M{"PhoneNumber": phonenumber},
		bson.M{"$set": bson.M{
			"Point": customer.Point + addpoint,
			"Rank":  r.GetByPointRank(customer.Point + addpoint),
		}})
	return err
}
