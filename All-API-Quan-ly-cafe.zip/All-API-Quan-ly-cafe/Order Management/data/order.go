package data

import (
	"errors"
	"strings"
	"time"
	"unicode"

	"github.com/Order/models"
	"gopkg.in/mgo.v2/bson"
)

//CreateOneOrder .
func (r *Repository) CreateOneOrder(order *models.Order) error {
	count, _ := r.Ordercol.Find(bson.M{"OrderID": order.OrderID}).Count()
	if count == 0 {
		objid := bson.NewObjectId()
		order.ID = objid
		order.Status = true
		err := r.Ordercol.Insert(&order)
		return err
	}
	return errors.New("Order already exist")
}

//GetAllOrder .
func (r *Repository) GetAllOrder() []models.Order {
	var orders []models.Order
	iter := r.Ordercol.Find(nil).Sort("OrderID").Iter()
	result := models.Order{}
	for iter.Next(&result) {
		orders = append(orders, result)
	}

	return orders
}

//GetAllByWaiter .
func (r *Repository) GetAllByWaiter() []models.Order {
	var orders []models.Order
	iter := r.Ordercol.Find(bson.M{"$or": []interface{}{bson.M{"StatusOrder": "Ordered"}, bson.M{"StatusOrder": "Processing"}, bson.M{"StatusOrder": "Served"}}}).Sort("OrderID").Iter()
	result := models.Order{}
	for iter.Next(&result) {
		orders = append(orders, result)
	}
	return orders
}

//GetAllByBarista .
func (r *Repository) GetAllByBarista() []models.Order {
	var orders []models.Order
	iter := r.Ordercol.Find(bson.M{"$or": []interface{}{bson.M{"StatusOrder": "Ordered"}, bson.M{"StatusOrder": "Processing"}}}).Sort("OrderID").Iter()
	result := models.Order{}
	for iter.Next(&result) {
		orders = append(orders, result)
	}
	return orders
}

//GetAllByCashier .
func (r *Repository) GetAllByCashier() []models.Order {
	var orders []models.Order
	iter := r.Ordercol.Find(bson.M{"$or": []interface{}{bson.M{"StatusOrder": "Served"}, bson.M{"StatusOrder": "Completed"}}}).Sort("OrderID").Iter()
	result := models.Order{}
	for iter.Next(&result) {
		orders = append(orders, result)
	}
	return orders
}

//GetByIDOrder .
func (r *Repository) GetByIDOrder(id string) (models.Order, error) {
	var order models.Order
	err := r.Ordercol.Find(bson.M{"OrderID": id}).One(&order)
	return order, err
}

//UpdateOrder .
func (r *Repository) UpdateOrder(order *models.Order) error {
	var Timedone int
	if order.FinishedOn != (time.Time{}) {
		Timedone = CalculateMinutes(order.CreatedOn, order.FinishedOn)
	} else {
		Timedone = order.TimeDone
	}
	err := r.Ordercol.Update(bson.M{"OrderID": order.OrderID},
		bson.M{"$set": bson.M{
			"CreatedOn":   order.CreatedOn,
			"CreatedBy":   order.CreatedBy,
			"CompletedOn": order.CompletedOn,
			"CompletedBy": order.CompletedBy,
			"FinishedOn":  order.FinishedOn,
			"FinishedBy":  order.FinishedBy,
			"TimeDone":    Timedone,
			"PhoneNumber": order.PhoneNumber,
			"Discount":    order.Discount,
			"Total":       order.Total,
			"Cash":        order.Cash,
			"Change":      order.Change,
			"StatusOrder": order.StatusOrder,
			"Status":      order.Status,
			"Foods":       order.Foods,
		}})

	return err
}

//DeleteOneOrder .
func (r *Repository) DeleteOneOrder(id string) error {
	err := r.Ordercol.Update(bson.M{"OrderID": id},
		bson.M{"$set": bson.M{
			"Status": false,
		}})

	return err
}

//CalculateMinutes .
func CalculateMinutes(start time.Time, end time.Time) int {
	diff := end.Sub(start)
	return int(diff.Minutes())
}

//ToFirstUpper .
func ToFirstUpper(s string) string {
	if len(s) < 1 { // if the empty string
		return s
	}
	// Trim the string
	t := strings.Trim(s, " ")
	// Convert all letters to lower case
	t = strings.ToLower(t)
	res := []rune(t)
	// Convert first letter to upper case
	res[0] = unicode.ToUpper(res[0])
	return string(res)
}
