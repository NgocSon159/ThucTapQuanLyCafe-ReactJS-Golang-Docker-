package models

import (
	"time"

	"gopkg.in/mgo.v2/bson"
)

type (
	//Order .
	Order struct {
		ID          bson.ObjectId `bson:"_id,omitempty" json:"id"`
		OrderID     string        `bson:"OrderID"`
		CreatedOn   time.Time     `bson:"CreatedOn"`
		CreatedBy   string        `bson:"CreatedBy"`
		CompletedOn time.Time     `bson:"CompletdeOn"`
		CompletedBy string        `bson:"CompletedBy"`
		FinishedOn  time.Time     `bson:"FinishedOn"`
		FinishedBy  string        `bson:"FinishedBy"`
		TimeDone    int           `bson:"TimeDone"`
		PhoneNumber string        `bson:"PhoneNumber"`
		Discount    int           `bson:"Discount"`
		Total       int           `bson:"Total"`
		Cash        int           `bson:"Cash"`
		Change      int           `bson:"Change"`
		StatusOrder string        `bson:"StatusOrder"`
		Status      bool          `bson:"Status"`
		Foods       []Food        `bson:"Foods"`
	}

	//Food .
	Food struct {
		FoodID   string `bson:"FoodID"`
		Name     string `bson:"Name"`
		Size     string `bson:"Size"`
		Price    int    `bson:"Price"`
		Quantity int    `bson:"Quantity"`
		Sum      int    `bson:"Sum"`
		Note     string `bson:"Note"`
	}
)
