package routers

import (
	"github.com/Order/controllers"
	"github.com/gorilla/mux"
)

//SetRouters .
func SetRouters(router *mux.Router) *mux.Router {
	router.HandleFunc("/orders", controllers.GetAllOrdersEndPoint).Methods("GET")
	router.HandleFunc("/orders/{id}", controllers.GetOrderByIDEndPoint).Methods("GET")
	router.HandleFunc("/waiter", controllers.GetAllByWaiterEndPoint).Methods("GET")
	router.HandleFunc("/barista", controllers.GetAllByBaristaEndPoint).Methods("GET")
	router.HandleFunc("/cashier", controllers.GetAllByCashierEndPoint).Methods("GET")
	router.HandleFunc("/orders", controllers.CreateOneOrderEndPoint).Methods("POST")
	router.HandleFunc("/orders/{id}", controllers.UpdateOrderEndPoint).Methods("POST")
	router.HandleFunc("/orders/{id}", controllers.DeleteOrderByIDEndPoint).Methods("DELETE")
	return router
}
