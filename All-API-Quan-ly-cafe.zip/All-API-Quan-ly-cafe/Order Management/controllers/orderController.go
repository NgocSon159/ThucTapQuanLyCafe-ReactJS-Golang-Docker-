package controllers

import (
	"encoding/json"
	"errors"
	"net/http"

	"github.com/Order/common"
	"github.com/Order/data"
	"github.com/gorilla/mux"
	"gopkg.in/mgo.v2"
)

//CreateOneOrderEndPoint .
func CreateOneOrderEndPoint(w http.ResponseWriter, r *http.Request) {
	var dataResource OrderResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Order data", 500)
		return
	}
	order := &dataResource.Data
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	err = repo.CreateOneOrder(order)
	if nil != err {
		common.DisplayAppError(w, errors.New("Exist"), err.Error(), 500)
		return
	}
	j, err := json.Marshal(dataResource)
	if err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(j)
}

//GetAllOrdersEndPoint .
func GetAllOrdersEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	orders := repo.GetAllOrder()
	j, err := json.Marshal(OrdersResource{Data: orders})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetAllByWaiterEndPoint .
func GetAllByWaiterEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	orders := repo.GetAllByWaiter()
	j, err := json.Marshal(OrdersResource{Data: orders})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetAllByBaristaEndPoint .
func GetAllByBaristaEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	orders := repo.GetAllByBarista()
	j, err := json.Marshal(OrdersResource{Data: orders})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetAllByCashierEndPoint .
func GetAllByCashierEndPoint(w http.ResponseWriter, r *http.Request) {
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	orders := repo.GetAllByCashier()
	j, err := json.Marshal(OrdersResource{Data: orders})
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//GetOrderByIDEndPoint .
func GetOrderByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	order, err := repo.GetByIDOrder(id)
	if nil != err {
		if err == mgo.ErrNotFound {
			w.WriteHeader(http.StatusNotFound)
		} else {
			common.DisplayAppError(w, err, "An unexpected error has occured", 500)
		}
		return
	}
	j, err := json.Marshal(order)
	if nil != err {
		common.DisplayAppError(w, err, "An unexpected error has occured", 500)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(j)
}

//UpdateOrderEndPoint .
func UpdateOrderEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	var dataResource OrderResource
	err := json.NewDecoder(r.Body).Decode(&dataResource)
	if nil != err {
		common.DisplayAppError(w, err, "Invalid Order data", 500)
		return
	}
	order := &dataResource.Data
	order.OrderID = id
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	if err := repo.UpdateOrder(order); err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusOK)
}

//DeleteOrderByIDEndPoint .
func DeleteOrderByIDEndPoint(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	context := NewContext()
	defer context.Close()
	ordercol := context.DbCollection("Orders")
	repo := &data.Repository{Ordercol: ordercol}
	if err := repo.DeleteOneOrder(id); err != nil {
		common.DisplayAppError(w, err, "An unexpected error has occurred", 500)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
