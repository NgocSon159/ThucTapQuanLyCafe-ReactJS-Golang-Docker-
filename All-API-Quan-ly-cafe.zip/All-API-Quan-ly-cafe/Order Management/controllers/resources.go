package controllers

import "github.com/Order/models"

type (

	//OrdersResource .
	OrdersResource struct {
		Data []models.Order `json:"data"`
	}

	//OrderResource .
	OrderResource struct {
		Data models.Order `json:"data"`
	}
)
